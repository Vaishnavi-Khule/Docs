import grpc
from concurrent import futures
import time
import document_pb2
import document_pb2_grpc
import os

# Define the file path for storing the document content
DOCUMENT_FILE_PATH = "/home/vaishnavi/Assignments/Distributed_Homeworks/Q4/document.txt"

class DocumentService(document_pb2_grpc.DocumentServiceServicer):
    def SyncDocument(self, request_iterator, context):
        metadata = dict(context.invocation_metadata())
        username = metadata.get('username', 'unknown')
        
        for change in request_iterator:
            # Load the current document content from the file
            document_content = self.load_document()

            # Log the change made by the user
            self.log_change('doc1', change, username)

            # Process the change based on its type
            if change.change_type == document_pb2.ChangeType.ADD:
                # Append the content at the end of the document
                document_content += " " + change.content

            elif change.change_type == document_pb2.ChangeType.EDIT:
                # Modify content at the specified position
                if 0 <= change.position < len(document_content):
                    document_content = (document_content[:change.position] + change.content +
                                        document_content[change.position + len(change.content):])
                else:
                    print(f"Edit position {change.position} is out of bounds.")

            elif change.change_type == document_pb2.ChangeType.DELETE:
                # Remove content starting from the specified position
                if 0 <= change.position < len(document_content):
                    document_content = (document_content[:change.position] +
                                        document_content[change.position + len(change.content):])
                else:
                    print(f"Delete position {change.position} is out of bounds.")

            # Save the updated document content back to the file
            self.save_document(document_content)

            # Yield the updated document content back to the client
            yield document_pb2.DocumentResponse(document_id='doc1', content=document_content)

    def log_change(self, document_id, change, username):
        """Log the change made by a client, including the client's username."""
        with open("document_log.txt", "a") as log_file:
            log_file.write(
                f"Client: {username}, "
                f"Document ID: {document_id}, "
                f"Change Type: {change.change_type}, "
                f"Content: {change.content}, "
                f"Position: {change.position}\n"
            )

    def load_document(self):
        """Load the document content from the file, if it exists."""
        if os.path.exists(DOCUMENT_FILE_PATH):
            with open(DOCUMENT_FILE_PATH, "r") as file:
                return file.read()
        return ""  # Return an empty string if the file does not exist

    def save_document(self, content):
        """Save the document content to a file."""
        with open(DOCUMENT_FILE_PATH, "w") as file:
            file.write(content)

    def LogChange(self, request, context):
        """Handle the logging of changes."""
        self.log_change(request.document_id, request.change, "server")
        return document_pb2.LogChangeResponse(success=True)

def serve():
    """Start the gRPC server."""
    server = grpc.server(futures.ThreadPoolExecutor(max_workers=10))
    document_pb2_grpc.add_DocumentServiceServicer_to_server(DocumentService(), server)
    server.add_insecure_port('[::]:50051')
    server.start()
    print("Server started on port 50051.")
    try:
        # Keep the server running
        while True:
            time.sleep(86400)
    except KeyboardInterrupt:
        server.stop(0)

if __name__ == '__main__':
    serve()
