import grpc
import document_pb2
import document_pb2_grpc
from google.protobuf.empty_pb2 import Empty  # Import Empty from google.protobuf
import threading


def listen_for_updates(stub):
    """Listen for document updates from the server."""
    while True:
        try:
            # Use the imported Empty message
            for response in stub.StreamUpdates(Empty()):
                if hasattr(response, 'content'):
                    print(f"Updated Document Content: {response.content}")
                else:
                    print("Received an unexpected response format.")
        except grpc.RpcError as e:
            print(f"gRPC error: {e.details()}")
            break


def run():
    username = input("Enter your username: ").strip()
    with grpc.insecure_channel('localhost:50051') as channel:
        stub = document_pb2_grpc.DocumentServiceStub(channel)

        # Start a thread for listening to updates
        threading.Thread(target=listen_for_updates, args=(stub,), daemon=True).start()

        while True:
            try:
                change_type = input("Enter change type (add/edit/delete): ").strip().lower()
                if change_type not in ['add', 'edit', 'delete']:
                    raise ValueError("Invalid change type. Please enter 'add', 'edit', or 'delete'.")

                if change_type == 'add':
                    content = input("Enter content to append: ").strip()
                    change = document_pb2.DocumentChange(
                        change_type=document_pb2.ChangeType.ADD,
                        content=content,
                        position=-1  # Dummy value for position
                    )

                elif change_type == 'delete':
                    start_position = input("Enter start position: ").strip()
                    end_position = input("Enter end position: ").strip()
                    try:
                        start_position = int(start_position)
                        end_position = int(end_position)
                    except ValueError:
                        raise ValueError("Invalid position. Please enter valid integers.")

                    if start_position >= end_position:
                        raise ValueError("Start position must be less than end position.")

                    # For delete, pass the start_position and use the content to indicate the range
                    content = f"{start_position},{end_position}"

                    change = document_pb2.DocumentChange(
                        change_type=document_pb2.ChangeType.DELETE,
                        content=content,
                        position=start_position
                    )

                else:  # for edit
                    content = input("Enter new content: ").strip()
                    position = input("Enter position to edit: ").strip()
                    try:
                        position = int(position)
                    except ValueError:
                        raise ValueError("Invalid position. Please enter a valid integer.")

                    change = document_pb2.DocumentChange(
                        change_type=document_pb2.ChangeType.EDIT,
                        content=content,
                        position=position
                    )

                # Sending a single change in an iterable
                metadata = (('username', username),)
                response_iterator = stub.SyncDocument(iter([change]), metadata=metadata)

                for response in response_iterator:
                    print(f"Document successfully updated.")

            except ValueError as ve:
                print(f"Error: {ve}")
            except grpc.RpcError as e:
                print(f"gRPC error: {e.details()}")
            except Exception as e:
                print(f"An unexpected error occurred: {e}")


if __name__ == '__main__':
    run()
