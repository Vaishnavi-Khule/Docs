#!/bin/bash

# Install required packages
pip install grpcio grpcio-tools

# Generate gRPC code
python3 -m grpc_tools.protoc -I. --python_out=. --grpc_python_out=. document.proto

